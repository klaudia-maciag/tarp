def classFactory(iface):
    from .TARP_Plugin import TARP_Plugin
    return TARP_Plugin(iface)