import processing
from qgis.core import QgsProcessing

def run_tarpa(input_layer, id_field, warstwy_poligonowe=None, warstwy_liniowe=None, warstwy_punktowe=None):
    """
    Runs TARP A logic:
    - Merges GML polygon, line, and point layers
    - Calculates kodArgumentu field with CASE logic
    - Selects features where kodArgumentu is not null
    - Spatially joins back to input parcels

    Returns a dict with:
      'TARP_A': QgsVectorLayer (merged result),
      'Selekcja_Poligony': QgsVectorLayer or None,
      'Selekcja_Linie': QgsVectorLayer or None,
      'Selekcja_Punkty': QgsVectorLayer or None
    """
    warstwy_poligonowe = warstwy_poligonowe or []
    warstwy_liniowe = warstwy_liniowe or []
    warstwy_punktowe = warstwy_punktowe or []

    def kod_argumentu_formula():
        return '''CASE
WHEN array_to_string("funkcjaSzczegolowaBudynku", delimiter:=',') LIKE '%budynek wielorodzinny%' OR
     array_to_string("funkcjaSzczegolowaBudynku", delimiter:=',') LIKE '%siedziba firmy lub firm%' OR
     array_to_string("funkcjaSzczegolowaBudynku", delimiter:=',') LIKE '%centrum handlowe%' OR
     array_to_string("funkcjaSzczegolowaBudynku", delimiter:=',') LIKE '%dom towarowy lub handlowy%' OR
     array_to_string("funkcjaSzczegolowaBudynku", delimiter:=',') LIKE '%garaż%' OR
     array_to_string("funkcjaSzczegolowaBudynku", delimiter:=',') LIKE '%hipermarket lub supermarket%' OR
     array_to_string("funkcjaSzczegolowaBudynku", delimiter:=',') LIKE '%obiekt handlowo-usługowy%' THEN 1

WHEN "rodzaj" IN (
  'akwedukt','estakada','kładka','most','przejście dla zwierząt',
  'przejście podziemne dla pieszych','tunel','wiadukt',
  'podpora kolei linowej','wieża szybu kopalnianego',
  'szyb naftowy lub gazowy','kolej linowa','wyciąg narciarski',
  'kopalnia','wejście do stacji metra','bunkier lub schron',
  'wejście do jaskini lub groty'
) THEN 2

WHEN "layer" NOT LIKE '%OT_SKDR%' AND
     "polozenie" IN (
       'pod powierzchnią gruntu','ponad powierzchnią gruntu poziom 1',
       'ponad powierzchnią gruntu poziom 2','ponad powierzchnią gruntu poziom 3',
       'ponad powierzchnią gruntu poziom 4','pod powierzchnią','nad powierzchnią'
     ) THEN 2

WHEN "rodzaj" IN ('lądowisko dla helikopterów','pas startowy','lotnisko lub lądowisko') THEN 3

ELSE NULL
END'''

    def prepare_layer(layers):
        if not layers:
            return None
        merged = processing.run('native:mergevectorlayers', {
            'LAYERS': layers,
            'ADD_SOURCE_FIELDS': True,
            'CRS': 'ProjectCrs',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })['OUTPUT']
        try:
            merged = processing.run('native:deletecolumn', {
                'INPUT': merged,
                'COLUMN': ['path'],
                'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
            })['OUTPUT']
        except Exception:
            pass
        merged = processing.run('native:fieldcalculator', {
            'INPUT': merged,
            'FIELD_NAME': 'kodArgumentu',
            'FIELD_TYPE': 1,
            'FIELD_LENGTH': 2,
            'FIELD_PRECISION': 0,
            'FORMULA': kod_argumentu_formula(),
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })['OUTPUT']
        merged = processing.run('native:extractbyexpression', {
            'INPUT': merged,
            'EXPRESSION': '"kodArgumentu" is not null',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })['OUTPUT']
        processing.run('native:createspatialindex', {'INPUT': merged})
        return merged

    # spatial index on input parcels
    processing.run('native:createspatialindex', {'INPUT': input_layer})

    selekcja_pol = prepare_layer(warstwy_poligonowe)
    selekcja_lin = prepare_layer(warstwy_liniowe)
    selekcja_pkt = prepare_layer(warstwy_punktowe)

    outputs = {}
    join_layers = []

    if selekcja_pol:
        outputs['Selekcja_Poligony'] = selekcja_pol
        jr = processing.run('native:joinattributesbylocation', {
            'INPUT': input_layer,
            'JOIN': selekcja_pol,
            'PREDICATE': [0,1,2,3,4,5,6],
            'JOIN_FIELDS': ['kodArgumentu'],
            'METHOD': 0,
            'DISCARD_NONMATCHING': True,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })['OUTPUT']
        join_layers.append(jr)

    if selekcja_lin:
        outputs['Selekcja_Linie'] = selekcja_lin
        jr = processing.run('native:joinattributesbylocation', {
            'INPUT': input_layer,
            'JOIN': selekcja_lin,
            'PREDICATE': [0,1,2,3,4,5,6],
            'JOIN_FIELDS': ['kodArgumentu'],
            'METHOD': 0,
            'DISCARD_NONMATCHING': True,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })['OUTPUT']
        join_layers.append(jr)

    if selekcja_pkt:
        outputs['Selekcja_Punkty'] = selekcja_pkt
        jr = processing.run('native:joinattributesbylocation', {
            'INPUT': input_layer,
            'JOIN': selekcja_pkt,
            'PREDICATE': [0,1,2,3,4,5,6],
            'JOIN_FIELDS': ['kodArgumentu'],
            'METHOD': 0,
            'DISCARD_NONMATCHING': True,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })['OUTPUT']
        join_layers.append(jr)

    # final merge:
    if join_layers:
        final = processing.run('native:mergevectorlayers', {
            'LAYERS': join_layers,
            'ADD_SOURCE_FIELDS': False,
            'CRS': 'ProjectCrs',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        })['OUTPUT']
        outputs['TARP_A'] = final
    else:
        outputs['TARP_A'] = input_layer

    return outputs
