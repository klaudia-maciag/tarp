import processing
from qgis.PyQt.QtCore import QVariant
from qgis.core import QgsProject, QgsVectorLayer, QgsFeature, QgsFields, QgsField, QgsWkbTypes

def run_tarpb(input_layer: QgsVectorLayer, id_field: str) -> QgsVectorLayer:
    # 1. Build grouping data
    group_values = {}
    group_counts = {}
    group_repr = {}
    for feat in input_layer.getFeatures():
        key = feat[id_field]
        if key is None:
            continue
        if key not in group_repr:
            group_repr[key] = (feat.attributes(), feat.geometry())
        val = feat['kodArgumentu']
        if val is None:
            continue
        val_str = str(val)
        group_values.setdefault(key, set()).add(val_str)
        if key not in group_counts:
            group_counts[key] = {str(i): 0 for i in range(1, 7)}
        if val_str in group_counts[key]:
            group_counts[key][val_str] += 1

    # 2. Prepare output layer
    out_fields = QgsFields()
    for f in input_layer.fields():
        out_fields.append(f)
    out_fields.append(QgsField('agg_kodArgumentu', QVariant.String))
    for i in range(1, 7):
        out_fields.append(QgsField(f'totalArg{str(i).zfill(2)}', QVariant.Int))

    crs = input_layer.crs().toWkt()
    geom_type = QgsWkbTypes.displayString(input_layer.wkbType())
    out_layer = QgsVectorLayer(f"{geom_type}?crs={crs}", 'TARP B', 'memory')
    provider = out_layer.dataProvider()
    provider.addAttributes(out_fields)
    out_layer.updateFields()

    # 3. Populate features
    new_feats = []
    for key, (attrs, geom) in group_repr.items():
        feat = QgsFeature()
        feat.setFields(out_fields)
        base_attrs = attrs
        feat.setAttributes(base_attrs + [''] + [0]*6)
        # agg_kodArgumentu
        unique_vals = sorted(group_values.get(key, []))
        feat['agg_kodArgumentu'] = ','.join(unique_vals)
        # counts
        for idx, cf in enumerate([f'totalArg{str(i).zfill(2)}' for i in range(1,7)], start=len(base_attrs)+1):
            feat[idx] = group_counts.get(key, {}).get(str(int(cf[-2:])), 0)
        feat.setGeometry(geom)
        new_feats.append(feat)

    provider.addFeatures(new_feats)
    out_layer.updateExtents()

    # 4. Add totalArg field
    processed = processing.run("native:fieldcalculator", {
        'INPUT': out_layer,
        'FIELD_NAME': 'totalArg',
        'FIELD_TYPE': 1,
        'FIELD_LENGTH': 3,
        'FIELD_PRECISION': 0,
        'FORMULA': (
            'coalesce("totalArg01",0) + coalesce("totalArg02",0) + '
            'coalesce("totalArg03",0) + coalesce("totalArg04",0) + '
            'coalesce("totalArg05",0) + coalesce("totalArg06",0)'
        ),
        'OUTPUT': 'memory:'
    })['OUTPUT']

    return processed

# Optionally add to project
# QgsProject.instance().addMapLayer(processed)