# -*- coding: utf-8 -*-
"""
/***************************************************************************
 TARP_Plugin
                                 A QGIS plugin
 TARP A & B processing
                              -------------------
        begin                : 2025-07-31
 ***************************************************************************/
"""
from qgis.PyQt.QtWidgets import (
    QAction, QDialog, QVBoxLayout, QComboBox, QDialogButtonBox,
    QLabel, QListWidget
)
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject, QgsVectorLayer
import os

from .tarp_a_runner import run_tarpa
from .tarp_b_runner import run_tarpb


class TARPDialog(QDialog):
    def __init__(self, iface):
        # przekazujemy rodzica mainWindow, by dialog modalnie w OK działał poprawnie
        super().__init__(iface.mainWindow())
        self.iface = iface
        self.setWindowTitle("TARP")

        layout = QVBoxLayout(self)

        # Wybór warstwy działek
        layout.addWidget(QLabel("Wybierz warstwę działek:"))
        self.layerCombo = QComboBox()
        self.layers = [
            layer for layer in QgsProject.instance().mapLayers().values()
            if isinstance(layer, QgsVectorLayer)
        ]
        for lyr in self.layers:
            self.layerCombo.addItem(lyr.name())
        layout.addWidget(self.layerCombo)

        # Wybór pola ID działki
        layout.addWidget(QLabel("Wybierz pole identyfikatora działki:"))
        self.idFieldCombo = QComboBox()
        self.layerCombo.currentIndexChanged.connect(self.populate_fields)
        layout.addWidget(self.idFieldCombo)
        self.populate_fields()

        # Poligony GML (geomType == 2)
        layout.addWidget(QLabel("Warstwy poligonowe GML:"))
        self.polygonsList = QListWidget()
        self.polygonsList.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        self.polygons = [lyr for lyr in self.layers if lyr.geometryType() == 2]
        for lyr in self.polygons:
            self.polygonsList.addItem(lyr.name())
        layout.addWidget(self.polygonsList)

        # Linie GML (geomType == 1)
        layout.addWidget(QLabel("Warstwy liniowe GML:"))
        self.linesList = QListWidget()
        self.linesList.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        self.lines = [lyr for lyr in self.layers if lyr.geometryType() == 1]
        for lyr in self.lines:
            self.linesList.addItem(lyr.name())
        layout.addWidget(self.linesList)

        # Punkty GML (geomType == 0)
        layout.addWidget(QLabel("Warstwy punktowe GML:"))
        self.pointsList = QListWidget()
        self.pointsList.setSelectionMode(QListWidget.SelectionMode.MultiSelection)
        self.points = [lyr for lyr in self.layers if lyr.geometryType() == 0]
        for lyr in self.points:
            self.pointsList.addItem(lyr.name())
        layout.addWidget(self.pointsList)

        # OK / Anuluj
        self.buttonBox = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok |
            QDialogButtonBox.StandardButton.Cancel
        )
        self.buttonBox.accepted.connect(self.accept)
        self.buttonBox.rejected.connect(self.reject)
        layout.addWidget(self.buttonBox)

    def populate_fields(self):
        """Przeładowanie listy pól po zmianie warstwy działek."""
        self.idFieldCombo.clear()
        idx = self.layerCombo.currentIndex()
        if idx >= 0:
            self.idFieldCombo.addItems([f.name() for f in self.layers[idx].fields()])

    def selected_layer(self):
        idx = self.layerCombo.currentIndex()
        return self.layers[idx] if idx >= 0 else None

    def selected_id_field(self):
        return self.idFieldCombo.currentText()

    def selected_gml_layers(self):
        return {
            'polygons': [self.polygons[i.row()] for i in self.polygonsList.selectedIndexes()],
            'lines':    [self.lines[i.row()]    for i in self.linesList.selectedIndexes()],
            'points':   [self.points[i.row()]   for i in self.pointsList.selectedIndexes()],
        }


class TARP_Plugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        plugin_dir = os.path.dirname(__file__)
        icon_path = os.path.join(plugin_dir, 'icons', 'icon.png')
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()
        self.action = QAction(icon, "TARP", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&TARP", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("&TARP", self.action)
            self.iface.removeToolBarIcon(self.action)

    def run(self):
        dlg = TARPDialog(self.iface)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return

        layer_a = dlg.selected_layer()
        id_field = dlg.selected_id_field()
        gml = dlg.selected_gml_layers()

        # Uruchom TARP A
        outputs_a = run_tarpa(
            input_layer=layer_a,
            id_field=id_field,
            warstwy_poligonowe=gml['polygons'],
            warstwy_liniowe=gml['lines'],
            warstwy_punktowe=gml['points']
        )

        # Dodaj warstwy selekcji
        for key, title in [
            ('Selekcja_Poligony', 'Selekcja Poligony'),
            ('Selekcja_Linie',   'Selekcja Linie'),
            ('Selekcja_Punkty',  'Selekcja Punkty')
        ]:
            lay = outputs_a.get(key)
            if lay:
                lay.setName(title)
                QgsProject.instance().addMapLayer(lay)

        # Dodaj TARP A
        lay_a = outputs_a['TARP_A']
        lay_a.setName("TARP A")
        QgsProject.instance().addMapLayer(lay_a)

        # Uruchom TARP B
        lay_b = run_tarpb(lay_a, id_field)
        lay_b.setName("TARP B")
        # załaduj styl QML, jeśli jest
        style_path = os.path.join(os.path.dirname(__file__), 'style.qml')
        if os.path.exists(style_path):
            lay_b.loadNamedStyle(style_path)
            lay_b.triggerRepaint()
        QgsProject.instance().addMapLayer(lay_b)
